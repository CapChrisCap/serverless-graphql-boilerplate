'use strict'; // eslint-disable-line strict

const handle = require('./graphql/index').default;

module.exports.graphql = (event, context, callback) => {
  console.log('called');
  handle(event.body.query, event.body.variables)
    .then((response) => callback(null, JSON.stringify({
      statusCode: 200,
      body: JSON.stringify({
        message: 'Go Serverless v1.0! Your function executed successfully!',
        input: event,
      }),
    })))
    .catch((error) => callback(error));
};
