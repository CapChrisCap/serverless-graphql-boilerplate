module.exports = {
  AUTH_CLIENT_SECRET: undefined,
  AUTH_CLIENT_ID: undefined,
};
