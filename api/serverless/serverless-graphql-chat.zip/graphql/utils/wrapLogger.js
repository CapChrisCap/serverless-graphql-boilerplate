'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lodash = require('lodash');

exports.default = function (db) {
  return (0, _lodash.mapValues)(db, function (value, key) {
    return function (payload, context) {
      if (process.env.NODE_ENV !== 'test') {
        console.log('----> ' + key + ' - ' + JSON.stringify(payload));
      }
      return value(payload, context);
    };
  });
};