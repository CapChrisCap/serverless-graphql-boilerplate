'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _lodash = require('lodash');

exports.default = function (db) {
  return (0, _lodash.mapValues)(db, function (value) {
    return function (payload, context) {
      return Promise.resolve(value(payload, context));
    };
  });
};