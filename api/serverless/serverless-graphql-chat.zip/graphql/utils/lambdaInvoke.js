'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

var _isLambdaEnvironment = require('./isLambdaEnvironment');

var _isLambdaEnvironment2 = _interopRequireDefault(_isLambdaEnvironment);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var LAMBDA_CONFIG = (0, _isLambdaEnvironment2.default)() ? { apiVersion: '2015-03-31' } : { apiVersion: '2015-03-31', region: 'us-west-2' };

var lambda = new _awsSdk2.default.Lambda(LAMBDA_CONFIG);

exports.default = function (functionName, payload) {
  var params = {
    FunctionName: functionName,
    Payload: JSON.stringify(payload)
  };

  return lambda.invoke(params).promise().then(function (response) {
    return JSON.parse(response.Payload);
  });
};