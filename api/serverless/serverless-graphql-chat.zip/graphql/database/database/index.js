'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _wrapLogger = require('../../utils/wrapLogger');

var _wrapLogger2 = _interopRequireDefault(_wrapLogger);

var _getViewer = require('./getViewer');

var _getViewer2 = _interopRequireDefault(_getViewer);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var database = {
  getViewer: _getViewer2.default
};

exports.default = (0, _wrapLogger2.default)(database);