'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _addType = require('../utils/addType');

var _addType2 = _interopRequireDefault(_addType);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import addTypes from '../utils/addTypes';

var envVariable = process.env.MOCKED_DATABASE || 'false';
var useMockedDatabase = ('' + envVariable).toLowerCase() === 'true';

// eslint-disable-next-line global-require
var db = useMockedDatabase ? require('./mockedDatabase').default : require('./database').default;

exports.default = _extends({}, db, {
  getViewer: (0, _addType2.default)(db.getViewer, 'user')
});