'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _uuidJs = require('uuid-js');

var _uuidJs2 = _interopRequireDefault(_uuidJs);

var _wrapLogger = require('../../utils/wrapLogger');

var _wrapLogger2 = _interopRequireDefault(_wrapLogger);

var _wrapPromise = require('../../utils/wrapPromise');

var _wrapPromise2 = _interopRequireDefault(_wrapPromise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var database = {
  getViewer: function getViewer(_params) {
    return {
      id: _uuidJs2.default.create().toString(),
      name: 'Ada Lovelace'
    };
  }
};

exports.default = (0, _wrapLogger2.default)((0, _wrapPromise2.default)(database));