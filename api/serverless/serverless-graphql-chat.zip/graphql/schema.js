'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

require('babel-polyfill');

var _graphql = require('graphql');

var _query = require('./types/query');

var _query2 = _interopRequireDefault(_query);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import MutationType from './types/mutation';

// needed to for async/await

exports.default = new _graphql.GraphQLSchema({
  query: _query2.default
});