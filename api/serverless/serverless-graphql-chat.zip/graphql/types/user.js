'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _graphql = require('graphql');

var _graphqlRelay = require('graphql-relay');

var _node = require('../node');

var UserType = new _graphql.GraphQLObjectType({
  name: 'User',
  description: 'A person who uses our app',
  fields: function fields() {
    return {
      id: (0, _graphqlRelay.globalIdField)('User'),
      name: {
        type: _graphql.GraphQLString,
        description: 'The name of the user'
      }
    };
  },
  interfaces: [_node.nodeInterface]
});

exports.default = UserType;