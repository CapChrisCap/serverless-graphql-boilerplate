'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _graphql = require('graphql');

var _user = require('./user');

var _user2 = _interopRequireDefault(_user);

var _node = require('../node');

var _database = require('../database');

var _database2 = _interopRequireDefault(_database);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * This is the type that will be the root of our query,
 * and the entry point into our schema.
 */
var QueryType = new _graphql.GraphQLObjectType({
  name: 'Query',
  fields: function fields() {
    return {
      node: _node.nodeField,
      // Add your own root fields here
      viewer: {
        type: _user2.default,
        resolve: function resolve(_, _args, context) {
          return _database2.default.getViewer({}, context);
        }
      }
    };
  }
});

exports.default = QueryType;