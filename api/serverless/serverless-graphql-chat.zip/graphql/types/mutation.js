'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _graphql = require('graphql');

var MutationType = new _graphql.GraphQLObjectType({
  name: 'Mutation'
});

exports.default = MutationType;